# Using the templates

SVG layouts contain editable text and the complete approved logo. Open them in an SVG editor; preserve the logo group. Text uses Courier New with Courier/monospace fallback. Font files are not included. If the exact font is missing, install a legitimately licensed copy or use the documented fallback and check line wrapping.

- **Partner horizontal (1200 × 280):** replace the `replace-with-partner-logo` group with approved partner artwork. Rawchunks left; wordmark baseline alignment; start at equal cap height then balance optical weight. Total logo gap equals one cap height; optional neutral divider midway.
- **Partner stacked (800 × 560):** only when the full-name horizontal lockup would become too small. Center both logos optically; equal visual weight and one cap-height separation on each side of the divider.
- **Partner announcement (1200 × 630):** 64px outer safe area; 58/70px headline, 24/34px supporting text. Replace the partner logo and copy. Choose an accurate label: partnership, integration, or attribution. These placeholders imply no existing partnership.
- **Social post (1080 × 1080):** 64px safe area; 76/91px heading; 20px label/URL. Replace the image panel with a relevant product screenshot or an existing studio photo without recoloring it.
- **Presentation (1920 × 1080):** 96px margins; 92/111px title, 32/45px body, 22px footer. Use a short headline and a large product visual.
- **Email signature (HTML):** edit name/role; host the supplied light PNG on a public HTTPS URL and replace the local image path. Paste the rendered table into the email client. Send yourself a test; many clients block remote images, so retain the linked name and URL in text.

Export only the size needed by the destination. For social/slide templates, the canvas already matches the intended application. Keep an editable source and export the final composition once. Do not publish template placeholders.
